import sys
import unittest

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from watchdog_widget import LIVE_DATA_STORE, ThreatScanner, record_scan


class SignalScoringTests(unittest.TestCase):
    def test_combined_scam_signals_cross_high_risk_threshold(self):
        samples = [
            "Bank officer: aapka account band ho jayega, abhi OTP bataiye",
            "Lottery ticket jeeta hai aapne 50 lakh, processing fee 5000 UPI karein",
            "Aapka PAN card block ho jayega, abhi link par update karein",
            "Tumhari private video mere paas hai, 10000 bhejo warna viral kar dunga",
            "Free Jio recharge 5 doston ko forward karo",
            "मैं सीबीआई से बोल रहा हूं, आपके पार्सल में ड्रग्स मिले हैं",
            "D1g1tal arr3st ke liye p.a.i.s.e bhejo",
        ]
        for text in samples:
            with self.subTest(text=text):
                result = ThreatScanner.scan(text)
                self.assertGreater(result["score"], 75)
                self.assertEqual(result["level"], "HIGH")
                self.assertTrue(result["reasons"])

    def test_awareness_and_context_are_not_high_risk_scams(self):
        samples = [
            "Digital arrest se kaise bache - like share subscribe",
            "Nifty ne 3 saal mein 100% return diya",
            "Why 10x returns are impossible",
            "share like subscribe awareness",
        ]
        for text in samples:
            with self.subTest(text=text):
                result = ThreatScanner.scan(text)
                self.assertLessEqual(result["score"], 75)
                self.assertNotEqual(result["level"], "HIGH")

    def test_common_financial_how_to_queries_do_not_create_alerts(self):
        samples = [
            "Income tax refund status kaise check karein",
            "Post office scheme me paisa kaise lagaye",
            "Credit card ka PIN kaise change karein",
            "Fixed deposit vs mutual funds",
            "Bank me deposit kaise kare",
            "RBI ne UPI limit badhai",
        ]
        for text in samples:
            with self.subTest(text=text):
                self.assertLessEqual(ThreatScanner.scan(text)["score"], 75)

    def test_foreground_page_detection_requires_youtube_title_suffix(self):
        self.assertTrue(ThreatScanner.is_youtube_window_title("video name - YouTube - Google Chrome"))
        self.assertTrue(ThreatScanner.is_youtube_window_title("YouTube - Microsoft Edge"))
        self.assertFalse(ThreatScanner.is_youtube_window_title("lottery results - Google Search - Google Chrome"))
        self.assertFalse(ThreatScanner.is_youtube_window_title("Google Chrome - YouTube tips"))

    def test_threshold_and_reason_fields_are_explainable(self):
        result = ThreatScanner.scan("Please share your OTP immediately or your account will be blocked")
        self.assertEqual(result["level"], "HIGH")
        self.assertGreater(result["score"], 75)
        self.assertIn("Credential/OTP request", result["reasons"])
        self.assertTrue(result["evidence"])

    def test_each_scan_is_recorded_and_only_flagged_items_enter_alerts(self):
        LIVE_DATA_STORE["recent_scans"] = []
        LIVE_DATA_STORE["live_events"] = []
        LIVE_DATA_STORE["total_scanned_count"] = 0
        safe_text = "Daily weather update"
        scam_text = "Bank officer says account closes today; send OTP immediately"
        record_scan(safe_text, ThreatScanner.scan(safe_text), "test")
        record_scan(scam_text, ThreatScanner.scan(scam_text), "test")
        self.assertEqual(LIVE_DATA_STORE["total_scanned_count"], 2)
        self.assertEqual(len(LIVE_DATA_STORE["recent_scans"]), 2)
        self.assertEqual(len(LIVE_DATA_STORE["live_events"]), 1)
        self.assertGreater(LIVE_DATA_STORE["recent_scans"][0]["score"], 75)


if __name__ == "__main__":
    unittest.main()
