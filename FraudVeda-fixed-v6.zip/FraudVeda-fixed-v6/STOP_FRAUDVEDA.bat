@echo off
title Stop FraudVeda AI
color 0C
cd /d "%~dp0"

echo Stopping FraudVeda widget copies from any extracted version folder...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$targets = @('FraudVeda.exe','SocialSentinel_Chowkidaar.exe'); Get-CimInstance Win32_Process | Where-Object { $cmd=$_.CommandLine; $scriptWidget=($_.Name -match '^(python|pythonw)\.exe$' -and $cmd -match '(?i)FraudVeda.*watchdog_widget\.py'); $packedWidget=($targets -contains $_.Name -and $_.ExecutablePath -match '(?i)\\FraudVeda[^\\]*\\'); $scriptWidget -or $packedWidget } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"

echo.
echo FraudVeda stop request completed. Other Python apps and services are left untouched.
timeout /t 2 >nul
exit /b 0
