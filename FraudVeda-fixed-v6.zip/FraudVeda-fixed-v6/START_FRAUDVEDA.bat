@echo off
title FraudVeda - Local Threat Review
cd /d "%~dp0"

where py >nul 2>&1
if errorlevel 1 (
  where python >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python 3 with Tkinter is required. Install it and retry.
    pause
    exit /b 1
  )
  start "FraudVeda Engine" cmd /k python "%~dp0watchdog_widget.py"
) else (
  start "FraudVeda Engine" cmd /k py -3 "%~dp0watchdog_widget.py"
)

echo Waiting for the local analysis service...
powershell -NoProfile -Command "$ready=$false; for($i=0;$i -lt 20;$i++){try{$c=New-Object Net.Sockets.TcpClient;$c.Connect('127.0.0.1',8765);$c.Close();$ready=$true;break}catch{Start-Sleep -Seconds 1}}; if($ready){exit 0}else{exit 1}"
if errorlevel 1 (
  echo ERROR: FraudVeda did not start. Check the engine window for details.
  pause
  exit /b 1
)

echo Local service is ready. Opening dashboard...
start "" "http://127.0.0.1:8765/index.html"
echo Monitoring starts paused. Enable it from the floating widget when needed.
echo The widget currently analyzes visible window titles, not captions or audio.
echo Use STOP_FRAUDVEDA.bat to stop only this package's process.
pause
