# FRAUDVEDA prototype

## Run

1. Extract the ZIP completely.
2. Run `START_FRAUDVEDA.bat`.
3. The local dashboard opens at `http://127.0.0.1:8765/index.html`.
4. Monitoring starts paused. Open the floating widget menu and enable it only when you want to test a public YouTube page.
5. When upgrading, run `STOP_FRAUDVEDA.bat` from the new folder first; it closes FraudVeda widget copies from extracted versions, then start the new package. The widget prevents duplicate launches of the current version.

Requires Python 3 with Tkinter. The launcher runs the reviewed source only and will not fall back to the stale bundled executable. It confirms that the local dashboard server is listening before opening the dashboard.

## What this prototype actually checks

- The dashboard feed and included examples are synthetic demo content.
- The desktop widget checks the active foreground window title after the user enables it. If a YouTube video ID appears in that title, it may request the public YouTube oEmbed title/author metadata.
- Foreground monitoring accepts YouTube-style browser titles only; Google Search and other pages are ignored. Delayed title lookups are discarded if the same YouTube window/title is no longer active.
- Ordinary finance/how-to wording (for example, “PIN kaise change karein” or “deposit kaise kare”) is not treated as a payment or credential demand by itself.
- The alert’s **Skip** action focuses the previously detected YouTube window and sends one downward wheel event over the Shorts viewer; Windows may still prevent focus changes in some configurations.
- It does not read webpage DOM, video captions, audio, private messages, credentials, account age, or actual link destinations. It is not a Chrome extension and does not continuously inspect every website.
- Detection uses local phrase/rule matching. Scores are heuristic indicators for human review, not verified facts or real-world accuracy measurements.
- No rule engine can enumerate every scam variation. This prototype combines generic risk signals with known patterns; it can still miss new scams or raise false positives, so verify independently.
- Scores above 75/100 are labeled high-risk indicators and trigger the alert overlay; scores 35–75 remain reviewable indicators. No score proves that a post is fraudulent.
- The dashboard scan history shows up to 200 checks for the current server session, including evidence, reason signals, source, score, and review state. History is in memory and clears when the app closes.
- The clipboard watcher has been removed. No clipboard content is polled.
- Dashboard/API state is local and in memory or browser `localStorage`; it is not a persistent server database.

## Tests

Use Python 3.10+ with Tkinter available. From this folder, run:

```powershell
python test_audit.py
python test_50_videos.py
python test_extended_audit.py
python -m unittest -v test_signal_scoring.py
```

These are curated synthetic test cases. Passing them is not evidence of real-world detection accuracy.

## Privacy and safety

The local HTTP service binds to `127.0.0.1:8765`. The API accepts only small JSON requests, validates scan text, and restricts review decisions. Do not expose the local service to a network or treat alerts as accusations. The STOP script avoids killing unrelated applications that happen to use port 8765.
